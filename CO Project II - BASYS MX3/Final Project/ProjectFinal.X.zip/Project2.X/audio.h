

#ifndef _AUDIO_H    /* Guard against multiple inclusion */
#define _AUDIO_H

#define NC 523
#define ND 587
#define NE 659
#define NF 698
#define NG 784
#define NA 880
#define NB 987
#define NC2 1046
#define SONG_LENGTH 24

void play_audio();
void stop_audio();
void init_audio();
void update_audio();
#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
