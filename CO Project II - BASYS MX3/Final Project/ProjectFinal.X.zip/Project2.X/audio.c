#include <xc.h>  
#include <sys/attribs.h>
#include "config.h"
//#include "lcd.h"
#include "sim.h"
#include "audio.h"
//interrupt handler for Timer3.  just clear interrupt flag
void __ISR(_TIMER_3_VECTOR, IPL7AUTO) Timer3ISR(void) 
{  
    IFS0bits.T3IF = 0;      // clear Timer3 interrupt flag
}   

void play_audio()
{    
    T3CONbits.ON = 1;       // turn on Timer3
    OC1CONbits.ON = 1;      // Turn on OC1
}
void stop_audio()
{
    IFS0bits.T3IF = 0;      // clear Timer3 interrupt flag    
    T3CONbits.ON = 0;       // turn off Timer3
    OC1CONbits.ON = 0;      // Turn off OC1
    IFS0bits.T3IF = 0;      // clear Timer3 interrupt flag
}

int audio_period = 40000; //number of cycles between Timer3 interrupts.  40000000 is just for initialization
void init_audio(){        
    tris_A_OUT = 0;     // Configure AUDIO output as digital output.
    rp_A_OUT = 0x0C;    // 1100 = OC1
    ansel_A_OUT = 0;    // // disable analog (set pins as digital)   
    
    PR3 = audio_period; //number of cycles between Timer3 interrupts
    OC1R = audio_period / 2;
    OC1RS = audio_period / 2;
    
    TMR3 = 0;
    T3CONbits.TCKPS = 1;     //1:256 prescale value
    T3CONbits.TGATE = 0;     //not gated input (the default)
    T3CONbits.TCS = 0;       //PCBLK input (the default)
    T3CONbits.ON = 0;        //turn on Timer3
 
    OC1CONbits.ON = 0;       // Turn off OC1 while doing setup.
    OC1CONbits.OCM = 6;      // PWM mode on OC1; Fault pin is disabled
    OC1CONbits.OCTSEL = 1;   // Timer3 is the clock source for this Output Compare module
    OC1CONbits.ON = 1;       // Start the OC1 module  

    IPC3bits.T3IP = 6;      // interrupt priority
    IPC3bits.T3IS = 3;      // interrupt subpriority
    IEC0bits.T3IE = 0;      // disable Timer3 interrupt    
    IEC0bits.T3IE = 0;      // disable Timer3 interrupt    
    IFS0bits.T3IF = 0;      // clear Timer3 interrupt flag
    //macro_enable_interrupts();  // enable interrupts at CPU
}




int audio_timestamp=0;
int song[SONG_LENGTH] = {NG, NE, NE, NF, ND, ND, NC, ND, NE, NF, NG, NG, NG, NG,
                NE, NE, NF, ND, ND, NC, NE, NG, NG, NC}; //, NE, NE, ND, NC, NC};
int duration[SONG_LENGTH] = {1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 2, 1, 1, 
                    2, 1, 1, 2, 1, 1, 1, 1, 4}; //,2, 2, 2, 2, 6};

int current_time;
int note_index=0;
int durationCount=0;
void update_audio(){
    
    current_time =_CP0_GET_COUNT();
    int note_time = 40000000/8;   //   sec/8=128msec    e.c every 128msec move to next note.
    if(current_time-audio_timestamp>note_time){   
        audio_timestamp=(current_time/note_time)*note_time;
        if(++durationCount<duration[note_index])
            return;
        durationCount=0;        
        note_index =(note_index+1)%SONG_LENGTH; // song is cyclic        
        //calculate number of cycles between interrupts: (0.5*clock_rate)/note_frequency
        audio_period = 20000000/song[note_index];   
        PR3 = audio_period;
        OC1R = audio_period / 2;
        OC1RS = audio_period / 2;
    }
}