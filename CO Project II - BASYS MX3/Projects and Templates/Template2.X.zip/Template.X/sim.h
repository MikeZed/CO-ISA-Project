/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */


#ifndef _SIM_H    /* Guard against multiple inclusion */
#define _SIM_H

//#define _CRT_SECURE_NO_WARNINGS
#define TRUE 1 
#define FALSE 0

#define MAX_LINES 1000 
#define SIZE 5
#define LINE_SIZE 4
#define REG_SIZE 16
#define IOREG_SIZE 6



int reg[REG_SIZE];
char memout[MAX_LINES][SIZE];
char* inst[LINE_SIZE];
int buttons[5], swts[8];
int pc, num_of_reg, address_of_mem, flag_Write, ioReg[IOREG_SIZE], 
        inst_count, pause, single_step, count_ToWrite, max_line_counter,flag ;


/*Utility func*/
int positiveValue(int num);
int getHex(char* source);
int hex2int(char ch);
int getAddress(int address);
void REG_Init();
void IOREG_Init();
/*Create func*/
//void createTrace(FILE* trace, int pc, char line[SIZE], int reg[REG_SIZE], int* count);

/*Line Func*/
void add(int rd, int rs, int rt);
void sub(int rd, int rs, int rt);
void mul(int rd, int rs, int rt);
void andf(int rd, int rs, int rt);
void orf(int rd, int rs, int rt);
void sll(int rd, int rs, int rt);
void sra(int rd, int rs, int rt);
void limm(int rd, char memin[MAX_LINES][SIZE]);
void branch(int rd, int rs, int rt, char memin[MAX_LINES][SIZE]);
void jal(char memin[MAX_LINES][SIZE]);
void lw(int rd, int rs);
void sw(int rd, int rs, char memin[MAX_LINES][SIZE]);
void in(int rd, int rs, char memin[MAX_LINES][SIZE]);
void out(int rd, int rs, char memin[MAX_LINES][SIZE]);
void halt();
void decipher_line(char line[SIZE], char memin[MAX_LINES][SIZE]);
void address_Init();
void write_inst();
void write_mem();
void write_reg();
void write_count();
int sim(char memin[MAX_LINES][SIZE]);





#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
