#include "config.h"
#include "lcd.h"
#include "led.h"
//#include "timed.h"
#include "utils.h"
#include "rgbled.h"
#include "btn.h"
#include "ssd.h"
#include "sim.h"
#include <xc.h>  
#include <sys/attribs.h>
#include <string.h>
     
//==================================================
//              Global Configuration
//==================================================
// Device Config Bits in  DEVCFG1:	
#pragma config FNOSC =	FRCPLL
#pragma config FSOSCEN =	OFF
#pragma config POSCMOD =	EC
#pragma config OSCIOFNC =	ON
#pragma config FPBDIV =     DIV_2

// Device Config Bits in  DEVCFG2:	
#pragma config FPLLIDIV =	DIV_2
#pragma config FPLLMUL =	MUL_20
#pragma config FPLLODIV =	DIV_1

#define _XTAL_FREQ 8000000
#define TMR_TIME1 0.001
#define TMR_TIME4 0.001
#pragma config JTAGEN = OFF
#pragma config FWDTEN = OFF


void Timer1Setup()
{
  // The following configurations set the PR1 value and the PreScaling factor 
  PR1 = (int)(((float)(TMR_TIME1 * PB_FRQ) / 64)) - 1; //set period register, generates one interrupt every 2 ms
  TMR1 = 0;                           //    initialize count to 0
  T1CONbits.TCKPS = 2;                //    1:64 prescale value
  
  T1CONbits.TGATE = 0;                //    not gated input (the default)
  T1CONbits.TCS = 0;                  //    PCBLK input (the default)
  T1CONbits.ON = 1;                   //    turn on Timer1
  IPC1bits.T1IP = 7;                  //    priority
  IPC1bits.T1IS = 3;                  //    subpriority
  IFS0bits.T1IF = 0;                  //    clear interrupt flag
  IEC0bits.T1IE = 1;                  //    enable interrupt
  //macro_enable_interrupts();          //    enable interrupts at CPU
}

 /*
     Checks SWT0 and SWT1 and determine which printing is required 
     */
void Update_LCD_Neccessery_Content()
{
    if(swts[0])
    {
        if(swts[1])
            flag_Write = 3;
        else
            flag_Write = 1;
    }
    else
        if(swts[1])
            flag_Write = 2;
        else
            flag_Write = 0;
}
void BTNU_Press()
{
    if(BTN_GetValue(0) != buttons[0]) // BTNU Pressed and Released
    {
        buttons[0] = 0;
        switch (flag_Write)
        {           
            case 1:
                num_of_reg = (num_of_reg + 1)%16; // Add 1 to the number of register that needs to be printed (Circularly)
                break;
            case 2:
                address_of_mem = (address_of_mem + 1)%4096; // Add 1 to the address of the memory that needs to be printed (Circularly)
                          
        }
    }
}
void BTNL_Press()
{
    if(BTN_GetValue(1) != buttons[1] ) // BTNL Pressed and released
    {
        buttons[1] = 0;
        buttons[3] = 0;
        single_step = 0;
        pause = (pause + 1)%2;
        if(!pause)
        {
            TMR5 = 0;
            count_ToWrite = 0;
        }
    }  
}
void BTNR_Press()
{
    if(BTN_GetValue(3) != buttons[3] ) // BTNR Pressed and released  
    {
        buttons[3] = 0; 
        if(single_step > 0)
            single_step += 1;
        else
            single_step = 1;
    }   
}
void buttons_Update()
{
    int i = 0;
    for (; i < 5 ; i++) // Updates buttons 
    {
        if(!buttons[i])
            buttons[i] = BTN_GetValue(i);
    }
}
void switches_Update()
{
    int i = 0;   
    for (; i < 8 ; i++) // Updates Switches
    {        
        swts[i] = SWT_GetValue(i);
    }  
}

//==============================================================================
//Interrupt Handler- handled every 1msec
//==============================================================================

void __ISR(_TIMER_1_VECTOR, ipl7) Timer1SR(void)
{      
    int change_address=0;
    if(swts[6] != SWT_GetValue(6) || (swts[5] != SWT_GetValue(5) && !SWT_GetValue(6))) // check if address initialization is needed 
    {
        swts[5] = SWT_GetValue(5);
        swts[6] = SWT_GetValue(6);
        change_address = 1;
    }
    
    if(++count_ToWrite==1000) //Count how many Interruptions were occurred since last writing to LCD
    {
        time_To_Write = 1;
        count_ToWrite = 0;
    }
    
    buttons_Update();
    switches_Update();
    
    if(change_address)
        address_of_mem_Init(); 
    /*
     Checks SWT0 and SWT1 and determine which printing is required 
     */
    Update_LCD_Neccessery_Content();
    
    /*
     Checks if BTN[u,l,r] have been pressed
     */
    BTNU_Press();
    BTNL_Press();
    BTNR_Press();
    
    write_To_SSD();
    IFS0bits.T1IF = 0;                  // clear interrupt flag    
}

//==============================================================================
//this function initializes the needed components
//==============================================================================
void init(){     
    LCD_Init();
    LED_Init();
    BTN_Init();   
    REG_Init();  
    SWT_Init();  
    
    RGBLED_Timer5Setup();    
    Timer1Setup();    
    
    int i = 0;
    for (; i < 5 ; i++) // Init buttons 
            buttons[i] = BTN_GetValue(i);
    i = 0;
    for (; i < 8 ; i++) // Init Switches     
        swts[i] = SWT_GetValue(i);
    
    address_of_mem_Init();    
    IOREG_Init();
    variables_Init();   
}
/*
 Initialize all Global flags and variables
 */
void variables_Init()
{
    sprintf(inst,"%s","0000"); 
    pc = 0;
    time_For_Inst = 0;
    inst_count = 0;
    num_of_reg = 0;
    max_line_counter = 0; 
    flag_Write = 0;
    time_To_Write =0;
    pause = 0;
    single_step = 0;
    count_ToWrite = 0;
    flag = 0;
    simp_Interrupt_Ongoing = 1; 
    time_To_Play = 0;
}

/*
 first initialize all lines of memout
 secondly copy memin into memout
 */
void MEMOUT_Init(char memin[MAX_LINES][SIZE], int max_line_counter)
{
	//init memout to be same as memin
	int i = 0;
	for (; i < MAX_LINES; i++)
		sprintf(memout[i], "%s","0000");
	i = 0;
	for (; i < max_line_counter; i++)
		sprintf(memout[i],"%s", memin[i]);
    //LCD_WriteStringAtPos(memout[0],0,0);
    //LCD_WriteStringAtPos(memin[0],1,0);
}
char fib[MAX_LINES][SIZE] , stopper[MAX_LINES][SIZE] ;
int fib_Lines, stopper_Lines;
int main() {
    
    init(); //initialize all needed componentm  
    array_Define();
    if(SWT_GetValue(7))
    {
        max_line_counter = fib_Lines;
        MEMOUT_Init(fib,max_line_counter);
        sim(fib);             
    }
    else
    {
        SSD_Init();
        max_line_counter = stopper_Lines;   
        MEMOUT_Init(stopper,max_line_counter);        
        sim(stopper);       
    }
    return 0;
}

void array_Define()
{
    char fib1[MAX_LINES][SIZE] = {"7D00",
    "0080",
    "A300",
    "0040",
    "9000",
    "0009",
    "B200",
    "0041",
    "F000",
    "7500",
    "0003",
    "1DD5",
    "B9D0",
    "0002",
    "BFD0",
    "0001",
    "B3D0",
    "0000",
    "7600",
    "0001",
    "8236",
    "0019",
    "0230",
    "0DD5",
    "86F0",
    "7500",
    "0001",
    "1335",
    "9000",
    "0009",
    "0920",
    "A3D0",
    "0000",
    "7500",
    "0002",
    "1335",
    "9000",
    "0009",
    "0229",
    "A3D0",
    "0000",
    "AFD0",
    "0001",
    "A9D0",
    "0002",
    "7500",
    "0003",
    "0DD5",
    "86F0",
    "0000",
    "0000",
    "0000",
    "0000",
    "0000",
    "0000",
    "0000",
    "0000",
    "0000",
    "0000",
    "0000",
    "0000",
    "0000",
    "0000",
    "0000",
    "0007" };
    fib_Lines = sizeof(fib1)/sizeof(fib1[0]);
    int i = 0;
    for (; i < fib_Lines ; i++)
    {
        sprintf(fib[i],"%s",fib1[i]);
    }
char stopper1[MAX_LINES][SIZE] = {"8000",
"002D",
"B5D0",
"FFFF",
"B6D0",
"FFFE",
"7500",
"0002",
"1DD5",
"C500",
"0001",
"7600",
"0001",
"3656",
"8060",
"0014",
"8190",
"0014",
"7E00",
"0001",
"7600",
"0002",
"3656",
"8060",
"001C",
"7600",
"0001",
"1969",
"7600",
"0004",
"3656",
"8060",
"0025",
"7A00",
"0000",
"7B00",
"0000",
"7500",
"0002",
"0DD5",
"A5D0",
"FFFF",
"A6D0",
"FFFE",
"8700",
"7D00",
"012C",
"7500",
"0001",
"7600",
"0002",
"7700",
"00C8",
"D000",
"0000",
"D000",
"0001",
"D600",
"0002",
"D700",
"0003",
"D000",
"0004",
"D000",
"0005",
"D500",
"0000",
"7A00",
"0000",
"7B00",
"0000",
"7900",
"0000",
"0AAE",
"7E00",
"0000",
"7700",
"003B",
"85A7",
"0059",
"7800",
"0001",
"0BB8",
"0878",
"1AA8",
"83B8",
"0059",
"7B00",
"0000",
"7700",
"0001",
"37B7",
"8070",
"006A",
"81A0",
"006A",
"E000",
"E000",
"E000",
"E000",
"E000",
"E000",
"E000",
"E000",
"E000",
"E000",
"03B0",
"9000",
"007A",
"0820",
"7500",
"0008",
"5885",
"03A0",
"9000",
"007A",
"0828",
"D800",
"0005",
"8000",
"0049",
"F000",
"B5D0",
"FFFF",
"B6D0",
"FFFE",
"B7D0",
"FFFD",
"7500",
"0003",
"1DD5",
"7500",
"000A",
"7600",
"0001",
"0730",
"7200",
"0000",
"8375",
"0090",
"1775",
"0226",
"8475",
"008C",
"7500",
"000A",
"2652",
"1636",
"7500",
"0004",
"5225",
"0226",
"7500",
"0003",
"0DD5",
"A5D0",
"FFFF",
"A6D0",
"FFFE",
"A7D0",
"FFFD",
"86F0"};
    stopper_Lines = sizeof(stopper1)/sizeof(stopper1[0]);
    i = 0;
    for (; i < stopper_Lines ; i++)
    {
        sprintf(stopper[i],"%s",stopper1[i]);
    }
}



