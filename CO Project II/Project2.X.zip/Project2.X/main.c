#include "config.h"
#include "lcd.h"
#include "led.h"
//#include "timed.h"
#include "utils.h"
#include "rgbled.h"
#include "btn.h"
#include "sim.h"
#include <xc.h>  
#include <sys/attribs.h>
#include <string.h>
     
//==================================================
//              Global Configuration
//==================================================
// Device Config Bits in  DEVCFG1:	
#pragma config FNOSC =	FRCPLL
#pragma config FSOSCEN =	OFF
#pragma config POSCMOD =	EC
#pragma config OSCIOFNC =	ON
#pragma config FPBDIV =     DIV_2

// Device Config Bits in  DEVCFG2:	
#pragma config FPLLIDIV =	DIV_2
#pragma config FPLLMUL =	MUL_20
#pragma config FPLLODIV =	DIV_1

#define _XTAL_FREQ 8000000
#define TMR_TIME 0.001
#pragma config JTAGEN = OFF
#pragma config FWDTEN = OFF


void SSD_Timer1Setup()
{
  // The following configurations set the PR1 value and the PreScaling factor 
  PR1 = (int)(((float)(TMR_TIME * PB_FRQ) / 64)) - 1; //set period register, generates one interrupt every 2 ms
  TMR1 = 0;                           //    initialize count to 0
  T1CONbits.TCKPS = 2;                //    1:64 prescale value
  
  T1CONbits.TGATE = 0;                //    not gated input (the default)
  T1CONbits.TCS = 0;                  //    PCBLK input (the default)
  T1CONbits.ON = 1;                   //    turn on Timer1
  IPC1bits.T1IP = 7;                  //    priority
  IPC1bits.T1IS = 3;                  //    subpriority
  IFS0bits.T1IF = 0;                  //    clear interrupt flag
  IEC0bits.T1IE = 1;                  //    enable interrupt
  //macro_enable_interrupts();          //    enable interrupts at CPU
}

/*void Timer4Setup()
{        
                                          //  setup peripheral
        PR4 = (int)(((float)(TMR_TIME4*PB_FRQ)/64)-1);                        //             set period register, generates one interrupt every 1 ms
        TMR1 = 0;                           //             initialize count to 0
        T1CONbits.TCKPS = 6;                //            1:256 prescale value
        T1CONbits.TGATE = 0;                //             not gated input (the default)
        T1CONbits.TCS = 0;                  //             PCBLK input (the default)
        T1CONbits.ON = 1;                   //             turn on Timer1
        IPC1bits.T4IP = 3;                  //             priority
        IPC1bits.T4IS = 0;                  //             subpriority
        IFS0bits.T4IF = 0;                  //             clear interrupt flag
        IEC0bits.T4IE = 1;                  //             enable interrupt
  
    
}*/

//==============================================================================
//Interrupt Handler- handled every 1msec
//==============================================================================

void __ISR(_TIMER_1_VECTOR, ipl7) Timer1SR(void)
{   int change_address=0;
    if(swts[6] != SWT_GetValue(6) || (swts[5] != SWT_GetValue(5) && !SWT_GetValue(6)))
        change_address=1;
    if(++count_ToWrite==1000) //Count how many Interruptions were occured since last writing to LCD
    {
        time_To_Write = 1;
        count_ToWrite = 0;
    }
    int i = 0;
    for (; i < 5 ; i++) // Updates buttons 
    {
        if(!buttons[i])
            buttons[i] = BTN_GetValue(i);
    }
    i = 0;
    for (; i < 8 ; i++) // Updates Switches
    {        
        swts[i] = SWT_GetValue(i);
    }  
    if(change_address)
        address_Init();
    if(swts[0])
    {
        if(swts[1])
            flag_Write = 3;
        else
            flag_Write = 1;
    }
    else
        if(swts[1])
            flag_Write = 2;
        else
            flag_Write = 0;
    if(BTN_GetValue(1) != buttons[1] ) // BTNL Pressed and released
    {
        buttons[1] = 0;
        buttons[3] = 0;
        single_step = 0;
        pause = (pause + 1)%2;
        if(!pause)
        {
            TMR5 = 0;
            count_ToWrite = 0;
        }
    }
    if(BTN_GetValue(3) != buttons[3] ) // BTNR Pressed and released  
    {
        buttons[3] = 0; 
        if(single_step > 0)
            single_step += 1;
        else
            single_step = 1;
    }
   
    if(BTN_GetValue(0) != buttons[0]) // BTNU Pressed and Released
    {
        buttons[0] = 0;
        switch (flag_Write)
        {           
            case 1:
                num_of_reg = (num_of_reg + 1)%16;
                break;
            case 2:
                address_of_mem = (address_of_mem+1)%4096;
                          
        }
    }
    
    IFS0bits.T1IF = 0;                  // clear interrupt flag
}

//==============================================================================
//this function initializes the needed components
//==============================================================================
void init(){ 
    LCD_Init();
    LED_Init();
    BTN_Init();   
    REG_Init();  
    SWT_Init();    
    RGBLED_Timer5Setup();    
    SSD_Timer1Setup();    
    max_line_counter = 0; 
    sprintf(inst,"%s","0000");
    pc = 0;
    time_For_Inst = 1;
    inst_count = 0;
    num_of_reg = 0;
    int i = 0;
    for (; i < 5 ; i++) // Init buttons 
            buttons[i] = BTN_GetValue(i);
    i = 0;
    for (; i < 8 ; i++) // Init Switches     
        swts[i] = SWT_GetValue(i);     
    address_Init();
    IOREG_Init();
    flag_Write = 0;
    time_To_Write =0;
    pause = 0;
    single_step = 0;
    count_ToWrite = 0;
    flag = 0;
}
void MEMOUT_Init(char memin[MAX_LINES][SIZE], int max_line_counter)
{
	//init memout to be same as memin
	int i = 0;
	for (; i < MAX_LINES; i++)
		sprintf(memout[i], "%s","0000");
	i = 0;
	for (; i < max_line_counter; i++)
		sprintf(memout[i],"%s", memin[i]);
    //LCD_WriteStringAtPos(memout[0],0,0);
    //LCD_WriteStringAtPos(memin[0],1,0);
}





int main(int argc, char** argv){
    
    init(); //initialize all needed componentm
    char fib[MAX_LINES][SIZE] = { 
            "7D00",
            "0080",
            "A300",
            "0040",
            "9000",
            "0009",
            "B200",
            "0041",
            "F000",
            "7500",
            "0003",
            "1DD5",
            "B9D0",
            "0002",
            "BFD0",
            "0001",
            "B3D0",
            "0000",
            "7600",
            "0001",
            "8236",
            "0019",
            "0230",
            "0DD5",
            "86F0",
            "7500",
            "0001",
            "1335",
            "9000",
            "0009",
            "0920",
            "A3D0",
            "0000",
            "7500",
            "0002",
            "1335",
            "9000",
            "0009",
            "0229",
            "A3D0",
            "0000",
            "AFD0",
            "0001",
            "A9D0",
            "0002",
            "7500",
            "0003",
            "0DD5",
            "86F0",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0007" };
char stopper[MAX_LINES][SIZE] = { "7D00",
            "0080",
            "A300",
            "0040",
            "9000",
            "0009",
            "B200",
            "0041",
            "F000",
            "7500",
            "0003",
            "1DD5",
            "B9D0",
            "0002",
            "BFD0",
            "0001",
            "B3D0",
            "0000",
            "7600",
            "0001",
            "8236",
            "0019",
            "0230",
            "0DD5",
            "86F0",
            "7500",
            "0001",
            "1335",
            "9000",
            "0009",
            "0920",
            "A3D0",
            "0000",
            "7500",
            "0002",
            "1335",
            "9000",
            "0009",
            "0229",
            "A3D0",
            "0000",
            "AFD0",
            "0001",
            "A9D0",
            "0002",
            "7500",
            "0003",
            "0DD5",
            "86F0",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0000",
            "0007" };

    if(SWT_GetValue(3))
    {
        max_line_counter = 65;
        MEMOUT_Init(fib,max_line_counter);
        IEC0bits.T5IE = 1;
        sim(fib);             
    }
    else
    {       
        max_line_counter = 65;        
        MEMOUT_Init(stopper,max_line_counter);
        IEC0bits.T5IE = 1;
        sim(stopper);       
    }
    return 0;
}





