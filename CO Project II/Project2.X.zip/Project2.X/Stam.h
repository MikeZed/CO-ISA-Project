
// Timer period in seconds
#define STAM_TMR_TIME    0.0003 // 300 us for each tick
void SSD_Timer1Setup();
long globaltime=0;
 