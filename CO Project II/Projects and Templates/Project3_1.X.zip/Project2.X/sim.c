/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

/* This section lists the other files that are included in this file.
 */

/* TODO:  Include other files here if needed. */
#include <xc.h>
#include <sys/attribs.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "sim.h"
#include "config.h"
#include "lcd.h"
#include "led.h"
#include "audio.h"
/* ************************************************************************** */
/* ************************************************************************** */
/* Section: File Scope or Global Data                                         */
/* ************************************************************************** */
/* ************************************************************************** */

/*  A brief description of a section can be given directly below the section
    banner.
 */
int missed_Inst = 0;
int sim(char memin[MAX_LINES][SIZE])
{
    TMR5 = 0;
    IEC0bits.T5IE = 1;                  //    enable interrupt TMR5
    while (1)
	{        
		while (pc > -1)
		{
            if(time_To_Play)                          
                update_audio();            
            else
                stop_audio();                                                                                                                                                                                   
            if(pause)
            {
                /*the single_step counts how many times the BTNR has been pushed in a row. 
                 * after performing one single step of the program, we reduce the counter's value by one.
                 * therefore the number of single steps to perform is reduced, 
                 * until it reaches 0(no more BTNR pushes to execute.). */
                if(time_To_Write)
                {
                    write_To_LCD();
                    time_To_Write = 0;
                    
                }
                if(single_step > 0)
                {
                    char line[SIZE];
                    sprintf(line,  "%s", memin[pc]);                        
                    decipher_line(line);
                    sprintf(inst,"%s",memin[pc]);
                    single_step -= 1;
                    inst_count +=1;                        
                }
                time_For_Inst = 1;
            }
            else
            {              
                T5CONbits.ON = 1;  
                time_For_Inst = 0;
                if(missed_Inst != 0)
                    missed_Inst--;                    
                if(time_To_Write)
                {
                    //T5CONbits.ON = 0;//stop the timer before printing 
                    write_To_LCD();
                    missed_Inst = 5;                                    
                    time_To_Write = 0;
                    //T5CONbits.ON = 1;//start the timer after printing
                }                              
                char line[SIZE];
                sprintf(line, "%s", memin[pc]);                    
                decipher_line(line);
                inst_count +=1;
                sprintf(inst,"%s",memin[pc]);   
                while(!time_For_Inst && missed_Inst == 0){} // wait until next instruction time 
            }  
		}        
        IEC0bits.T5IE = 0;                  //    disable interrupt of SIMP        
        if(time_To_Write) // keep printing after reaching HALT]
        {
            write_To_LCD();
            time_To_Write = 0;
        }
	}
    return 0;
}
void REG_Init()
{
	// Init of reg	
	int i = 0;
	for (; i < REG_SIZE; i++)
	{
		reg[i] = 0;
	}
}
void IOREG_Init()
{
	int i = 0;
	for (; i < IOREG_SIZE; i++)
	{
		ioReg[i] = 0;
	}
}
int getHex(char* source)
{
	int n = (int)strtol(source, NULL, 16);
	if ((n & 0x8000) != 0 )
		n |= 0xFFFF0000;
	return n;
}
int hex2int(char ch)
{
	if (ch >= '0' && ch <= '9')
		return ch - '0';
	if (ch >= 'A' && ch <= 'F')
		return ch - 'A' + 10;
	if (ch >= 'a' && ch <= 'f')
		return ch - 'a' + 10;	
	return -1;
}
int getAddress(int address)
{
	if (address < 0)
	{

		return -10;
	}

	if (address >= 4096)
	{
		address = address & 0x0FFF; //if given address is too high, take only 12 LSBs.		
	}

	return address;
}
int positiveValue(int num)
{
    if (num < 0)
		num &= 0x0000FFFF;
    return num;
}
/*Create Func*


/*LINE Func*/
void decipher_line(char line[SIZE]) {

	int opcode = hex2int(line[0]);
	int rd = hex2int(line[1]);
	int rs = hex2int(line[2]);
	int rt = hex2int(line[3]);
	if (opcode == 15)
	{
		halt();
		return;
	}
	if (rd == 0 && opcode != 8 && opcode != 11 && opcode != 9 && opcode != 14)
	{
		if (opcode >= 7)
			pc += 1;
		pc += 1;
		return;
	}
	switch (opcode)
	{
        case 0:	add(rd, rs, rt); break;	//The opcode is add
        case 1: sub(rd, rs, rt); break;    //The opcode is sub
        case 2: mul(rd, rs, rt); break;    //The opcode is mul
        case 3: andf(rd, rs, rt); break;    //The opcode is and
        case 4: orf(rd, rs, rt); break;    //The opcode is or
        case 5: sll(rd, rs, rt); break;    //The opcode is sll
        case 6: sra(rd, rs, rt); break;    //The opcode is sra

        case 7: limm(rd); pc += 1; break;    //The opcode is limm
        case 8: branch(rd, rs, rt); pc -= 1; break;    //The opcode is branch
        case 9: jal(); pc -= 1; break;    //The opcode is jal
        case 10: lw(rd, rs); pc += 1; break;    //The opcode is lw
        case 11: sw(rd, rs ); pc += 1; break;    //The opcode is sw

        case 12: in(rd, rs); pc += 1; break;
        case 13: out(rd, rs); pc += 1; break;
        case 14: play(); break;
        case 15: halt();    //The opcode is halt		
	}
	pc += 1;
}
void add(int rd, int rs, int rt)
{
	reg[rd] = reg[rs] + reg[rt];
}
void sub(int rd, int rs, int rt)
{
	reg[rd] = reg[rs] - reg[rt];
}
void mul(int rd, int rs, int rt)
{
	reg[rd] = reg[rs] * reg[rt];
}
void andf(int rd, int rs, int rt)
{
	reg[rd] = reg[rs] & reg[rt];
}
void orf(int rd, int rs, int rt)
{
	reg[rd] = reg[rs] | reg[rt];
}
void sll(int rd, int rs, int rt)
{
	reg[rd] = reg[rs] << reg[rt];
}
void sra(int rd, int rs, int rt)
{
	if (reg[rs] >= (int)pow(2, 15))
	{
		reg[rd] = reg[rs] >> reg[rt];
		int p = 15;
		int i = 0;
		for (; i < reg[rt]; i++, p--)
			reg[rd] += (int)pow(2, p);

	}
	else
		reg[rd] = reg[rs] >> reg[rt];
}
void limm(int rd)
{	
	reg[rd] = getHex(memout[pc + 1]);
}
void branch(int rd, int rs, int rt)
{	
	int imm = getHex(memout[pc + 1]);
	switch (rd)
	{
	case 0:
		if (reg[rs] == reg[rt])  //beq
			pc = getAddress(imm);
		else pc += 2;
		break;
	case 1:
		if (reg[rs] != reg[rt])  //bne
			pc = getAddress(imm);
		else pc += 2;
		break;
	case 2:
		if (reg[rs] > reg[rt]) //branch if greater than - bgt
			pc = getAddress(imm);
		else pc += 2;
		break;
	case 3:
		if (reg[rs] < reg[rt]) // branch if smaller than - bst
			pc = getAddress(imm);
		else pc += 2;
		break;
	case 4:
		if (reg[rs] >= reg[rt]) // beq or bgt
			pc = getAddress(imm);
		else pc += 2;
		break;
	case 5:
		if (reg[rs] <= reg[rt]) // beq or bst
			pc = getAddress(imm);
		else pc += 2;
		break;
	case 6: pc = getAddress(reg[rs]); // jump
        break;
    case 7 : ioReg[1] = 0; pc = ioReg[4]; LED_Control(); simp_Interrupt_Ongoing = 1;
	}
}
void jal()
{
	reg[15] = pc + 2;	
	int imm = positiveValue(getHex(memout[pc + 1]));
	pc = getAddress(imm);
}
void lw(int rd, int rs)
{
    char str[SIZE];
	int imm = getHex(memout[pc + 1]);
	int address = getAddress(imm + reg[rs]);
	sprintf(str, "%s", memout[address]);
	reg[rd] = getHex(str);
}
void sw(int rd, int rs)
{	
	int imm = getHex(memout[pc + 1]);
	int address = getAddress(imm + reg[rs]);    
	sprintf(memout[address], "%04X", reg[rd]);
    //LCD_WriteStringAtPos(memout[address],0,0);
	if (max_line_counter < address)//&& reg[rd] != 0
		max_line_counter = address;
}
void in(int rd, int rs)
{
  int imm = getHex(memout[pc+1]);
  reg[rd] = ioReg[rs+imm];
}

void out(int rd, int rs)
{
  int imm = getHex(memout[pc+1]);
  ioReg[rs + imm] = reg[rd]; 
}


void play()
{
    time_To_Play = 1;    
    play_audio();
    play_audio();
    play_audio();
    play_audio();
    LCD_WriteStringAtPos("Play",1,0);
}

void halt()
{
	pc = -10;//DESTROY!!
}
void address_of_mem_Init()
{
	if(swts[6])
	{
		address_of_mem = 0x400;
	}
	else
	{
		if(swts[5])
		{
			address_of_mem =0x100;
		}
		else
		{
			address_of_mem =0x000;
		}
    }
}

/*
 all write instruction uses white spaces to overwrite the text that was there before.
 */
void write_count()
{
	char str_count[30];
	sprintf(str_count, "Count: %d             ",inst_count );	
	LCD_WriteStringAtPos(str_count,0,0);
    LCD_WriteStringAtPos("               ",1,0);
}
void write_reg()
{
    char str_final[30];
    int registerPos = positiveValue(reg[num_of_reg]);
	sprintf(str_final, "R%02d = %04X                ", num_of_reg, registerPos);	
	LCD_WriteStringAtPos(str_final,0,0);
    sprintf(str_final, "TFP%02d                     ", time_To_Play);
    LCD_WriteStringAtPos(str_final,1,0);   
}
void write_mem()
{
    char str_MEM[30], str_RSP[30];
	int data_add = positiveValue(getHex( memout[address_of_mem]));	
	sprintf(str_MEM, "M%03X = %04X                 ", address_of_mem, data_add);    
	LCD_WriteStringAtPos(str_MEM,0,0);
    int regVal = positiveValue(reg[13]);
	sprintf(str_RSP, "RSP: %03X                 ", regVal);		
	LCD_WriteStringAtPos(str_RSP,1,0);
}
void write_inst()
{
    //LCD_WriteStringAtPos(memout[0],0,0);
    char str_final[30], str_pc[30];
    int pc_temp = pc;
    if(pc_temp < 0)    
        pc_temp &= 0x00000FFF;    
    sprintf(str_pc, "Pc: %03X           ", pc_temp);
	LCD_WriteStringAtPos(str_pc,1,0);	
	sprintf(str_final, "Inst: %s             ",inst );	
	LCD_WriteStringAtPos(str_final,0,0);
	
}


/* *****************************************************************************
 End of File
 */
