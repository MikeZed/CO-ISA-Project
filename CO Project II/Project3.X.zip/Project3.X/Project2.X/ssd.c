

#include <xc.h>
#include <sys/attribs.h>
#include "sim.h"
#include "config.h"
#include "ssd.h"
const unsigned char digitSegments[]= {
    0b1000000, // 0
    0b1111001, // 1
    0b0100100, // 2
    0b0110000, // 3
    0b0011001, // 4
    0b0010010, // 5
    0b0000010, // 6
    0b1111000, // 7
    0b0000000, // 8
    0b0010000, // 9
};



void SSD_Init()
{
    SSD_ConfigurePins(); 
    lat_SSD_CA = 0;
    lat_SSD_CB = 0;
    lat_SSD_CC = 0;
    lat_SSD_CD = 0;
    lat_SSD_CE = 0;
    lat_SSD_CF = 0;
    lat_SSD_CG = 0;
    lat_SSD_DP = 0;     
    lat_SSD_AN1 = 0; // activate digit 1;
    lat_SSD_AN2 = 0; // activate digit 2;    
    lat_SSD_AN3 = 0; // activate digit 3;   
    lat_SSD_AN0 = 0; // activate digit 0;
    
}

void SSD_Close()
{
    // turn off digits
    lat_SSD_AN1 = 1; // deactivate digit 1;
    lat_SSD_AN2 = 1; // deactivate digit 2;    
    lat_SSD_AN3 = 1; // deactivate digit 3;   
    lat_SSD_AN0 = 1; // deactivate digit 0;
}

void SSD_ConfigurePins()
{
    // set pins as digital outputs.
    tris_SSD_CA = 0;
    tris_SSD_CB = 0;
    tris_SSD_CC = 0;
    tris_SSD_CD = 0;  
    tris_SSD_CE = 0;
    tris_SSD_CF = 0;
    tris_SSD_CG = 0;
    tris_SSD_DP = 0;  
    
    tris_SSD_AN0 = 0;
    tris_SSD_AN1 = 0;
    tris_SSD_AN2 = 0;
    tris_SSD_AN3 = 0;    
    
    // disable analog (set pins as digital))    
    ansel_SSD_AN0 = 0;
    ansel_SSD_AN1 = 0;
    
    PMCONbits.ON = 0;   // turn PM off
}

int idx =0;
unsigned char digits[4];
void write_To_SSD()
{
	digits[0] = digitSegments[(ioReg[5] & 0x000F)%10]; // bits 0-3 of ioReg[5] represent the first digit to be displayed- seconds. 
	digits[1] = digitSegments[((ioReg[5] & 0x00F0) >> 4)%10]; //bits 4-7 of ioReg[5] represent the second digit to be displayed- tens seconds.
	digits[2] = digitSegments[((ioReg[5] & 0x0F00) >> 8)%10];//bits 8-11 of ioReg[5] represent the third digit to be displayed- minutes.
	digits[3] = digitSegments[((ioReg[5] & 0xF000) >> 12)%10];//bits 12-15 of ioReg[5] represent the second digit to be displayed- tens minutes.
	
    unsigned char currDigit;
    
    
    
    idx = (idx + 1)%4;
    lat_SSD_AN1 = 1; // deactivate digit 1;
    lat_SSD_AN2 = 1; // deactivate digit 2;    
    lat_SSD_AN3 = 1; // deactivate digit 3;   
    lat_SSD_AN0 = 1; // deactivate digit 0;
    currDigit = digits[idx];

    //     1. deactivate all digits (anodes)

    /*switch(i)
    {
        case 0:
            lat_SSD_AN0 = 1; // activate digit 0;        
            break;
        case 1:
           lat_SSD_AN1 = 1; // activate digit 1;
            break;
        case 2:
           lat_SSD_AN2 = 1; // activate digit 2;
            break;    
        case 3:
            lat_SSD_AN3 = 1; // activate digit 3;   
            break; 
    }   */

    lat_SSD_CA = currDigit & 0x01;
    lat_SSD_CB = (currDigit & 0x02) >> 1;
    lat_SSD_CC = (currDigit & 0x04) >> 2;
    lat_SSD_CD = (currDigit & 0x08) >> 3;    
    lat_SSD_CE = (currDigit & 0x10) >> 4;
    lat_SSD_CF = (currDigit & 0x20) >> 5;
    lat_SSD_CG = (currDigit & 0x40) >> 6;
    lat_SSD_DP = 1;     

    // 3. activate the current digit (anodes)
    switch(idx)
    {
        case 0:
            lat_SSD_AN0 = 0; // activate digit 0;        
            break;
        case 1:
           lat_SSD_AN1 = 0; // activate digit 1;
            break;
        case 2:
           lat_SSD_AN2 = 0; // activate digit 2;
            break;    
        case 3:
            lat_SSD_AN3 = 0; // activate digit 3;   
            break; 
    }    
        
	
    
}